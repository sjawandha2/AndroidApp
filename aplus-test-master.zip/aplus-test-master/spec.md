### Kotlin version
1.3.50

### targetSdkVersion
22 (Lollipop 5.1)