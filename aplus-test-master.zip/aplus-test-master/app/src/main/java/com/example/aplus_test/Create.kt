//package com.example.aplus_test
//
//import android.annotation.SuppressLint
//import android.content.Intent
//import androidx.appcompat.app.AppCompatActivity
//import android.os.Bundle
//import android.widget.Button
//import android.widget.LinearLayout
//
//class Create : AppCompatActivity() {
//    @SuppressLint("WrongViewCast")
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        title = "Create"
//
//        val notification_title_hint= findViewById<Button>(R.id.notification_title_hint)
//        val signature_due_date_hint = findViewById<Button>(R.id.signature_due_date_hint)
//        val enter_content_hint = findViewById<Button>(R.id.enter_content_hint)
//        val publish_button = findViewById<Button>(R.id.publish_button)
//
//        setContentView(R.layout.activity_creation)
//    }
//}