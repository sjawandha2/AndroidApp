package com.example.aplus_test

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout

class Summary : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title="Summary"
        setContentView(R.layout.activity_summary)

        startActivity(intent)
    }

    fun println(){

    }
}
