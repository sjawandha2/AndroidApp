package com.example.aplus_test

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_permission.view.*

/**
 * @author A++
 * Date: 10/25/2019
 * This class takes the user to the different location from given option based on their click.
 */
class MoreMenu : AppCompatActivity() {

    /**
     * This function instantiates the activity_more view
     */
    fun onResume(savedInstanceState: Bundle?) {
        val permissionSlips = findViewById<LinearLayout>(R.id.permissionSlip)
        permissionSlips.textView.text = "${R.string.permission_slip} ($MainActivity.notificationCount)"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title="MoreMenu"
        setContentView(R.layout.activity_more)

        // get reference to button example
//        val btnClickMe = findViewById<Button>(R.id.button2)
//        // set on-click listener
//        btnClickMe.setOnClickListener {
//            // your code to perform when the user clicks on the button
//            Toast.makeText(this@MoreMenu, "You clicked me.", Toast.LENGTH_SHORT).show()
//        }


        // when click on permission slips button on more page
        //onclickListener take to the permission slip page
        val permissionSlips = findViewById<LinearLayout>(R.id.permissionSlip)
        val permissionSlipButton = findViewById<TextView>(R.id.permissionSlipButton)
        permissionSlipButton.text = "Permission Slips (${MainActivity.notificationCount})"

        //MainActivity.notificationCount=1
        //Toast.makeText(tvLogout.context, notificationCount, Toast.LENGTH_SHORT).show()
        // hide the permission slip button when there are no notification
        if(MainActivity.notificationCount <= 0)
        {

            permissionSlips.visibility = View.GONE
        }


        permissionSlips.setOnClickListener {


            // your code to perform when the user clicks on the button
            val intent = Intent(this,PermissionSlipsMenu::class.java)
            startActivity(intent)
        }
    }

    fun summary(view: View) {}
}
