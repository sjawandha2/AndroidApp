package com.example.aplus_test

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
/**
 * @author A++
 * Date: 10/25/2019
 * This class views the permission slip.
 */
class Notifications : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_permission_old)
        title="Notifications"
    }
}
