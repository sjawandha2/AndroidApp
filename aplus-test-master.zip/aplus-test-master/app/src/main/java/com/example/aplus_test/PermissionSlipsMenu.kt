package com.example.aplus_test

import com.example.aplus_test.MainActivity
import android.content.Intent
import android.os.Bundle
import android.provider.SyncStateContract
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.isDigitsOnly
import kotlinx.android.synthetic.main.activity_more.*

/**
 * @author A++
 * Date: 10/25/2019
 * This class creates the view for permission slips and takes the user to more menu when
 * click on submit button.
 */

class PermissionSlipsMenu : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_permission)
        title = "Permission Slip"

        // get reference to button
        val Submit = findViewById<Button>(R.id.submit)

        Submit.setOnClickListener {


            val student = findViewById(R.id.student_name) as EditText
            val student_name: String = student.text.toString()

            if (student_name.isEmpty()) {
                Toast.makeText(this, "Student Name required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (student.text.contains("[0-9?]")) {
                Toast.makeText(this, "Student Name not validate", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (student_name.length > 30) {
                Toast.makeText(this, "Student Name too long", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val ID = findViewById(R.id.studentId) as EditText
            val student_ID: String = ID.text.toString()
            if(!student_ID.isDigitsOnly()){
                Toast.makeText(this, "Student ID numeric only", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if(student_ID.isEmpty()){
                Toast.makeText(this, "Student ID required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (student_ID.length > 8) {
                Toast.makeText(this, "Student ID too long", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }



            val parent = findViewById(R.id.parent_name) as EditText
            val parent_name: String = parent.text.toString()
            if (parent_name.isEmpty()) {
                Toast.makeText(this, "Parent Name required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (parent.text.contains("[0-9?]")) {
                Toast.makeText(this, "Parent Name not validate", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (parent_name.length > 30) {
                Toast.makeText(this, "Parent Name too long", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            //Toast.makeText(this, "$student_name entered", Toast.LENGTH_SHORT).show()


            val check = findViewById(R.id.checkBox) as CheckBox

            if (!check.isChecked) {
                Toast.makeText(this, "Check Box not checked", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }



            MainActivity.notificationCount--




//            val showStudentView = findViewById<TextView>(R.id.summary_student)
//
//            showStudentView.text = student_name
//
//
//            val showParentView = findViewById<TextView>(R.id.summary_parent)
//
//            showParentView.text = parent_name

//            val showStudentView = findViewById<TextView>(R.id.summary_student_name)
//
//            showStudentView.text = student_name
//
//
//            val showParentView = findViewById<TextView>(R.id.summary_parent_name)
//
//            showParentView.text = parent_name

            val showNotificationView = findViewById<TextView>(R.id.textView)

            showNotificationView.text = MainActivity.notificationCount.toString()


            val intent = Intent(this, Summary::class.java)

            intent.putExtra("Student_Name", student_name)

            startActivity(intent)

            //val intent = Intent(this, MoreMenu::class.java)
            //val intent = Intent(this, Summary::class.java)
            //startActivity(intent)
        }
    }


    fun summary(view: View) {

//        val showStudentView = findViewById<TextView>(R.id.summary_student_name)
//
//        showStudentView.text = student_name
//
//
//        val showParentView = findViewById<TextView>(R.id.summary_parent_name)
//
//        showParentView.text = parent_name
        }

}