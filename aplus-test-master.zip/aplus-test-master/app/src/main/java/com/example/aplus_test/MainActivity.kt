package com.example.aplus_test

import android.app.NotificationChannel
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.app.NotificationCompat
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TaskStackBuilder
import android.content.Context
import android.view.View
import androidx.core.app.NotificationManagerCompat

/**
 * @author A++
 * Date: 10/25/2019
 * This class creates the notifications and send to the user.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        var notificationCount = 0

    }

    // this variable must be incremented after each notification created
    private var notificationId = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        // this is used to reload the device state saved in the virtual device
        super.onCreate(savedInstanceState)

        // create the channel to receive Notifications
        createNotificationChannel()

        // set the main view on startup
        setContentView(R.layout.activity_main)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // name can be anything, android because it's easy to remember
            val name = "android"
            val descriptionText = "MoreMenu"


            val importance = NotificationManager.IMPORTANCE_DEFAULT

            // the id ("android") must match when using NotificationCompat.Builder
            val channel = NotificationChannel("android", name, importance).apply {
                description = descriptionText
            }

            // Register the channel with the system
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    /**
     * This function calls the MoreMenu to display the activity_more view
     */
    fun displayNotifications(v: View) {
        // create intent for the Notifications activity and switch to it immediately
        val intent = Intent(this,MoreMenu::class.java)
        startActivity(intent)
    }

    /**
     * This function prepares the variables for the notification
     */
    fun createNotification(v: View) {
        // create intent for the Notifications activity
        //val create = Intent(this, Create::class.java)

//        notificationCount++
        //startActivity(create)


        // create a pending intent object using this intent
        val pendingIntent: PendingIntent? = TaskStackBuilder.create(this).run {
            // Add the intent, which inflates the back stack
            addNextIntentWithParentStack(intent)
            // Get the PendingIntent containing the entire back stack
            getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT)
        }

        // build a notification using a default resource icon and some sample text
        val builder = NotificationCompat.Builder(this, "android")
            .setSmallIcon(R.drawable.ic_launcher_background)
            .setContentTitle("New Notification")
            .setContentText("This is a test notification.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)

        // using the notification manager from this context, call notify to push the notification
        with(NotificationManagerCompat.from(this)) {
            notify(notificationId++, builder.build())
        }

        notificationCount++
    }
}
